checkIfUserIsLoggedIn();
