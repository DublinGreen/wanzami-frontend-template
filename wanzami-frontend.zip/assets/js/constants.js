const AUTH_URL = 'https://auth-api.wanzami.tv/graphql';
const URL = 'http://localhost:8081/graphql';
const APP = 'WANZAMI'
const YEAR = '2025';
const COUNTRY_NAME_API = 'https://ipapi.co/json/';
const PAYSTACK_KEY = "pk_test_472a1f94c9759dfbe5088d1d891ea2a6d402179e";